//
//  IRTextFieldDrag.h
//  iReSign
//
//  Created by Esteban Bouza on 01/12/12.
//

#import <Cocoa/Cocoa.h>

@interface IRTextFieldDrag : NSTextField

@end
