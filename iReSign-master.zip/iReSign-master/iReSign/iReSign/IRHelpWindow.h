//
//  IRHelpWindow.h
//  iReSign
//
//  Created by Kramer on 12/13/13.
//  Copyright (c) 2013 nil. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface IRHelpWindow : NSWindow

// Close the window
- (IBAction)closeOK:(id)sender;

@end
